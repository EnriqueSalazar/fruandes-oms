-- MySQL dump 10.13  Distrib 5.6.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: oms_schema
-- ------------------------------------------------------
-- Server version	5.6.31-0ubuntu0.15.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes_table`
--

DROP TABLE IF EXISTS `clientes_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_clientes` text NOT NULL,
  `email_clientes` text,
  `telefono_clientes` text,
  `type` tinyint(4) NOT NULL,
  `jsonCustom` text,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes_table`
--

LOCK TABLES `clientes_table` WRITE;
/*!40000 ALTER TABLE `clientes_table` DISABLE KEYS */;
INSERT INTO `clientes_table` VALUES (2,'enrique salazar','enrique.salazar@gmail.com','3003003030',2,'{\"Dirección\":\"CASA\",\"Edad\":\"CASA\"}','0000-00-00 00:00:00','2016-12-05 18:14:53'),(3,'',NULL,NULL,0,NULL,'2016-11-13 23:04:16','2016-11-13 23:04:16'),(4,'Gabriel Garcia Salazar','gabodemayo100@gmail.com','3003003030',1,'{\"casa\":\"amarillas\",\"ccc\":\"eeeeef\"}','2016-11-13 23:04:52','2016-12-05 19:58:31'),(5,'oscar','walgasa@gmail.com',NULL,2,NULL,'2016-11-13 23:06:12','2016-11-29 20:08:09'),(6,'ONU','onu@mail.com','22222',3,NULL,'2016-11-14 00:44:50','2016-11-30 20:27:47'),(7,'juan carlos cardenas','juancardenas@gmail.com','300300301',1,NULL,'2016-11-17 00:04:49','2016-11-29 23:32:02');
/*!40000 ALTER TABLE `clientes_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-05 18:59:11
