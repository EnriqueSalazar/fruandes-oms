-- MySQL dump 10.13  Distrib 5.6.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: oms_schema
-- ------------------------------------------------------
-- Server version	5.6.31-0ubuntu0.15.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `areas_table`
--

DROP TABLE IF EXISTS `areas_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_area` text NOT NULL,
  `descripcion_area` text,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  `type` tinyint(4) NOT NULL,
  `deadline_proyecto` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas_table`
--

LOCK TABLES `areas_table` WRITE;
/*!40000 ALTER TABLE `areas_table` DISABLE KEYS */;
INSERT INTO `areas_table` VALUES (2,'GE - Planeación Estratégica',NULL,'2016-07-19 09:38:25','2016-07-19 09:38:25',1,NULL),(3,'GE - Marca y Comunicaciones',NULL,'2016-07-19 09:38:40','2016-07-19 10:57:21',1,NULL),(4,'GE - Desarrollo Social y Fundraising',NULL,'2016-07-19 09:39:00','2016-08-16 05:40:51',1,NULL),(5,'GO - Mantenimiento y Maquinaria',NULL,'2016-07-19 09:39:15','2016-08-13 03:45:09',1,NULL),(6,'GE - Re-localización Ibagué','','2016-07-19 09:39:42','2016-08-08 06:06:17',2,'2016-12-30'),(7,'GE - Sistema de Información OMS','OMS','2016-07-19 09:40:07','2016-09-06 20:14:11',2,'2016-10-28'),(8,'GE - Legal y Auditoría Interna',NULL,'2016-07-19 10:14:40','2016-07-19 10:14:40',1,NULL),(9,'GF - Gestión Financiera ',NULL,'2016-07-24 12:45:27','2016-08-11 05:20:53',1,NULL),(10,'GFA - Gestión Humana','','2016-07-31 10:58:57','2016-08-08 06:30:19',1,NULL),(12,'GC - Ventas Internacionales + Logística',NULL,'2016-07-31 12:06:04','2016-07-31 12:06:04',1,NULL),(13,'PP - Gestión Tecnica, Tecnológica e Investigación',NULL,'2016-08-08 07:13:59','2016-08-23 17:13:09',1,NULL),(14,'PP - Gestión Financiera & Desarrollo Organizacional',NULL,'2016-08-08 07:14:32','2016-08-08 07:14:32',1,NULL),(15,'GO - Procesamiento & Calidad',NULL,'2016-08-08 07:15:41','2016-11-23 14:06:00',1,NULL),(16,'GC - Ventas Nacionales + Iberoamérica (JustFruit)',NULL,'2016-08-09 07:43:39','2016-08-09 07:43:39',1,NULL),(17,'GAF - NIIF',NULL,'2016-08-10 01:29:14','2016-08-10 01:29:44',2,'2016-11-30'),(18,'GA- Gestión Administrativa','','2016-08-11 05:22:22','2016-11-10 20:21:52',1,NULL),(19,'PP-  Lote Posterior',NULL,'2016-08-11 05:25:31','2016-08-11 05:25:31',2,NULL),(20,'PP- colombia Responde',NULL,'2016-08-11 05:26:31','2016-08-11 05:26:31',2,NULL),(21,'GE- Nuevos Productos','El interés de este proyecto es el de agregar valor a los productos y subproductos que se generan en Fruandes; El proyecto se compone de diferentes sub-proyectos, (Sin embargo el planteamiento para el 2016 es de principalmente salida al mercado con los primeros 2 productos):   Productos deshidratados cubiertos con chocolate: Este proyecto tiene como objetivo utilizar la fruta deshidratada de segunda que se genera en los procesos, picarla hasta un tamaño ideal para bocado y posteriormente mediante la alianza de maquila con terceros y aliados estratégicos realizar el proceso de cobertura con chocolate orgánico; Compotas y mermeladas: Este proyecto nace por iniciativa de uno de nuestros clientes internacionales (Nathalie´s Direct Trade) para realizar el proceso de maquila de mermeladas inicialmente de dos sabores Uchuva y Mango-Maracuyá utilizando la fruta de nuestros proveedores; Barras de fruta: Posiblemente con fruta deshidratada y nueces y/ú otros granos; Infusiones aromáticas: Producto para realizar infusiones aromáticas hechas de mezclas de fruta orgánica deshidratada y hierbas aromáticas. Productos deshidratados + Nueces: Realizar mezclas de nuestra fruta con nueces orgánicas. Fruta en tela: Como opción para utilización de pulpas generadas en proceso.','2016-08-11 12:04:28','2016-08-13 08:26:33',2,'2016-12-31'),(22,'GE- Carbono Neutro- Residuo Cero',NULL,'2016-08-11 12:07:02','2016-08-11 12:07:25',2,'2016-12-31'),(23,'GE- Empaque Biodegradable','\"Fruandes tiene un gran interés en cerrar el ciclo de vida de los productos, es decir: Además de ofrecer una experiencia de sabor y Alimentación saludable que invita a asumir responsabilidad (Social y ambiental) Se cierra el ciclo de vida del producto al ofrecer al cliente final la posibilidad de poder desecharlo y reciclarlo en un proceso de descomposición química. En compostaje o en lugares apropiados para su disposición. \"				','2016-08-11 12:08:01','2016-11-11 21:17:18',2,'2016-10-25');
/*!40000 ALTER TABLE `areas_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-05 18:59:11
