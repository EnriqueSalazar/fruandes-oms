-- MySQL dump 10.13  Distrib 5.6.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: oms_schema
-- ------------------------------------------------------
-- Server version	5.6.31-0ubuntu0.15.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comentarios_areas_table`
--

DROP TABLE IF EXISTS `comentarios_areas_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comentarios_areas_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area_id` int(11) DEFAULT NULL,
  `meta_id` int(11) DEFAULT NULL,
  `tarea_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `comentario` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentarios_areas_table`
--

LOCK TABLES `comentarios_areas_table` WRITE;
/*!40000 ALTER TABLE `comentarios_areas_table` DISABLE KEYS */;
INSERT INTO `comentarios_areas_table` VALUES (1,9,33,23,9,'2016-08-08 05:44:44','2016-08-08 05:44:44',NULL,'Estoy atento de decisión para ajuste del semestre '),(2,9,28,25,9,'2016-08-08 05:46:32','2016-08-08 05:46:32',NULL,'Se dejó el recordatorio respectivo en el Calendar de Fruandes. Además el tramite se puede hacer actualmente por Internet'),(3,9,30,26,9,'2016-08-08 05:47:40','2016-08-08 05:47:40',NULL,'Queda pendiente una ultima revisión de los presupuestos para su ejecución desde agosto hasta diciembre. La idea es realizarla esta semana con Javier'),(4,9,28,38,9,'2016-08-08 05:49:58','2016-08-08 05:49:58',NULL,'Se habló con Eduardo, el actual contador, quedando pendiente legalizar su salida una vez se legalice la figura de trabajo con el nuevo asesor Financiero'),(5,5,0,0,14,'2016-08-13 08:43:15','2016-08-13 08:43:15',NULL,'\"El interés de este proyecto es el de garantizar que tecnología para que Fruandes sea más eficiente, productivo, exista más bienestar sostenibilidad. El proyecto se divide en 4 Sub-proyectos entre los cuales se encuentran: Máquinas deshidratadoras: Se trata de gestionar los procesos de adquisición y puesta a punto de equipos para deshidratación de fruta que la empresa requiere según su crecimiento'),(6,4,21,30,7,'2016-08-15 07:10:44','2016-08-15 07:10:44',NULL,'Proyecto en ejecución hasta el 24 de Diciembre 2016'),(7,4,20,53,7,'2016-08-15 07:15:10','2016-08-15 07:15:10',NULL,'Hicimos una sesión donde se definieron estos temas (Javier, Giovanni, Janir, Edisson, Mabel, Jennifer)'),(8,12,42,102,13,'2016-08-15 15:11:58','2016-08-15 15:11:58',NULL,'* Desde el viernes se soltaron las cotizaciones a los proveedores, espero tenerlas a mas tardar el miércoles en la mañana, el viernes se enviaron las muestras a ATM.'),(9,12,42,102,13,'2016-08-15 15:12:20','2016-08-15 15:12:20',NULL,'* SEN ENVIÓ LOS DATOS DE LA PRIMERA COTIZACIÓN EL MIÉRCOLES 3 AGOSTO'),(10,12,42,103,13,'2016-08-15 15:21:27','2016-08-15 15:21:27',NULL,'* Las muestras se enviaron el viernes 29 de Julio como se evidencia en los comunicados con Chantelle'),(11,12,42,103,13,'2016-08-15 15:21:51','2016-08-15 15:21:51',NULL,'* Se solicitaron nuevas muestras de papel a Proempaques, hay que revisar esta semana.'),(12,12,42,103,13,'2016-08-15 15:23:34','2016-08-15 15:23:34',NULL,'Se recibió muestra de papel, se hablará con Javier para solicitar autorización de elaboración de 2 cilindros para pruebas ($ 500.000)'),(13,12,42,104,13,'2016-08-15 15:26:38','2016-08-15 15:26:38',NULL,'* se tiene programado para que el miércoles 3 de agosto estén listos los borradores para que pasemos por la oficina de los srs, de la dian y obtener un revisión por parte de ellos.'),(14,12,42,104,13,'2016-08-15 15:26:51','2016-08-15 15:26:51',NULL,'* Se inició tramites:Fruandes se realizó reunión con Dietrans para la actualización de los criterios, el lunes se debe enviar toda la información para que hagan la actualización. Panela se envió documentación a Asoproomac; Se apartó cita en la 	DIAN Aeropuerto con el sr, Libardo para hablar sobre la cert. OEA… Miércoles 10 7:30am. '),(15,12,42,104,13,'2016-08-15 15:29:33','2016-08-15 15:29:33',NULL,'10/08/2016 Se enviaron los formularios a Dietrans para creación  de Criterios: Mango, banano, piña, uchuva, pitaya; También se enviaron todos los documentos para creación de Asoproomac ante la Dian en exportaciones'),(16,12,42,104,13,'2016-08-15 15:31:32','2016-08-15 15:31:32',NULL,'10/08/2016 Se asistió a reunión con la Dian donde explicaron a groso modo el proceso para la acreditación como OEA. Para esto se deberá internamente en fruandes crear un proyecto a mediano plazo para aplicar a este tramite.'),(17,12,42,104,13,'2016-08-15 15:32:31','2016-08-15 15:32:31',NULL,'- Se deben enviar los formatos para la creación de mixturas y panela a Dietrans a mas tardar el miercoles 17 de Agosto.'),(18,12,42,105,13,'2016-08-15 15:35:33','2016-08-15 15:35:33',NULL,' Bolsa Just Fruit 30g: Se enviaron modificaciones a Empaflexco'),(19,12,42,105,13,'2016-08-15 15:35:55','2016-08-15 15:35:55',NULL,'* Bolsa Panela LGT 500g: Se está esperando respuesta de LGT; se debe solicitar el cambio en la información dl dorso para que quede empacado por: Frandes; y s debe aclarar si se debe colocar producido por: ASOPROOMAC'),(20,12,42,105,13,'2016-08-15 15:37:08','2016-08-15 15:37:08',NULL,'Bolsa Just Fruit 30g: se recibieron artes modificados de empaflexco, pero no realizaron todas las modificaciones, se volvió a solcitar los artes corregidos'),(21,12,42,105,13,'2016-08-15 15:39:26','2016-08-15 15:39:26',NULL,'* Bolsa Panela LGT 500g: se reenvió nuevo arte de LGT a Empaflexco; también se solicitó a LGT aclaración en la declaración de ingredientes.'),(22,12,37,106,13,'2016-08-15 15:42:12','2016-08-15 15:42:12',NULL,'*pendiente de comunicarme con Emily: se envió información a Emily y se llamó para confirmar y explicar lo que allí dice.'),(23,15,50,107,13,'2016-08-15 16:16:49','2016-08-15 16:16:49',NULL,'se enviará EL LUNES 8 DE AGOSTO '),(24,15,50,107,13,'2016-08-15 16:17:13','2016-08-15 16:17:13',NULL,'Se entregó hoy el reporte.'),(25,15,50,108,13,'2016-08-15 16:20:23','2016-08-15 16:20:23',NULL,'*PENDIENTE RETOMAR COTIZACIONES'),(26,15,50,109,13,'2016-08-15 16:22:11','2016-08-15 16:22:11',NULL,'* SE TIENE SELECCIONADA LA DE EMPAQUE A GRANEL SELLADORA VERTCAL, COSTOS ESTIMADO 2,5 MILLONES'),(27,15,50,109,13,'2016-08-15 16:24:52','2016-08-15 16:24:52',NULL,'se envi+o orden de compra, y se inició la producción de la selladora; también se compro una selladora temporal para soportar los procesos de sellado mientras llega la nueva selladora.'),(28,15,50,110,13,'2016-08-15 16:28:00','2016-08-15 16:28:00',NULL,'* sigue requiriendo información y se le sigue respondiendo.; - se recibió correo donde informan que pasa a etapa de evaluación.'),(29,12,42,112,13,'2016-08-15 16:31:45','2016-08-15 16:31:45',NULL,'* Es solo medidas de las cajas… está pendiente. '),(30,12,42,112,13,'2016-08-15 16:33:32','2016-08-15 16:33:32',NULL,'01-8-2016 Se envió esta información a Gisselle y Luca'),(31,12,42,113,13,'2016-08-15 16:41:36','2016-08-15 16:41:36',NULL,'Ya se solicitó a Empaflexco.'),(32,12,42,113,13,'2016-08-15 16:43:35','2016-08-15 16:43:35',NULL,'8-08-2016 se recibió la ficha técnica pero errada'),(33,12,42,113,13,'2016-08-15 16:44:04','2016-08-15 16:44:04',NULL,'12-08-2016 se recibió la ficha técnica correcta'),(34,15,50,114,13,'2016-08-15 16:48:24','2016-08-15 16:48:24',NULL,' se envió correo solicitando aclaración a Daniel, se enviará tabla de documentos el martes 9 de agosto'),(35,12,40,115,13,'2016-08-15 16:54:31','2016-08-15 16:54:31',NULL,'* Se comprometío con el cliente enviarle comentarios acerca de la información de orgánico '),(36,12,40,115,13,'2016-08-15 16:56:43','2016-08-15 16:56:43',NULL,'10 de agosto: se recibieron los artes modificados por parte del cliente'),(37,12,40,115,13,'2016-08-15 16:57:42','2016-08-15 16:57:42',NULL,'12 de agosto: se respondió al cliente; adicional se enviaron los artes a BCS para aprobación'),(38,12,40,116,13,'2016-08-15 16:59:25','2016-08-15 16:59:25',NULL,' se envió la información hace dos semanas pero no se recibiío respuesta de recibido y Adriana de Jelly Shot preguntó de nuevo, se le informó que ya se le indicó al cliente, JAvi puedes preguntar a ellos. 16. - Revisión Artes OBELO.'),(39,12,40,117,13,'2016-08-15 17:03:01','2016-08-15 17:03:01',NULL,'se envió la información hace dos semanas pero no se recibiío respuesta de recibido y Adriana de Jelly Shot preguntó de nuevo, se le informó que ya se le indicó al cliente, JAvi puedes preguntar a ellos'),(40,12,40,117,13,'2016-08-15 17:06:02','2016-08-15 17:06:02',NULL,'JAvi, puedes hablar con Montesano, la semana pasada me escribió de nuevo Alejandra de Jelly Shot solicitándome de nuevo las tablas nutricionales, yo le reenivié el correo a ellos pero no he recibido respuesta.'),(41,12,40,118,13,'2016-08-15 17:10:08','2016-08-15 17:10:08',NULL,'12-08-2016 Se enviaron solicitud de modificaciones a información de etiquetas a Obelo '),(42,8,10,135,6,'2016-08-23 11:52:53','2016-08-23 11:52:53',NULL,'1. Carta de Cumplimiento al Fondo Inversor con lo que hemos cumplido: Reglamentos (Fabio), Pa y salvos de Proveedores (Edisson), Actualización Registro de Marca y Registro Comercial, Comité de Convivencia, Comercio Internacional 2. Pendientes: Sistema de Gestión en Salud y Seguridad y la Notificación a la Aseguradora, Contrato de Arrendamiento.'),(43,12,40,117,6,'2016-08-28 12:42:13','2016-08-28 12:42:13',NULL,'Es mejor dejar esto quieto hasta que ellos se vuelvan a contactar. Por favor escríbele a Adriana y dile que estamos esperando a que el cliente nos contacte.'),(44,2,3,0,5,'2016-11-16 22:28:47','2016-11-16 22:28:47',NULL,'hhhhh');
/*!40000 ALTER TABLE `comentarios_areas_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-05 18:59:11
