-- MySQL dump 10.13  Distrib 5.6.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: oms_schema
-- ------------------------------------------------------
-- Server version	5.6.31-0ubuntu0.15.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios_table`
--

DROP TABLE IF EXISTS `usuarios_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(45) NOT NULL,
  `email_usuario` varchar(45) NOT NULL,
  `perfil` varchar(45) DEFAULT NULL,
  `pwd` varchar(45) NOT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_table`
--

LOCK TABLES `usuarios_table` WRITE;
/*!40000 ALTER TABLE `usuarios_table` DISABLE KEYS */;
INSERT INTO `usuarios_table` VALUES (5,'Enrique Salazar','enrique.salazar@gmail.com','666','123456',NULL,'2016-11-11 20:52:19'),(6,'Javier Vasquez','javier@fruandes.coma','666','1234567890',NULL,'2016-11-10 01:13:55'),(7,'Jennifer Gonzalez','jennifer@fruandes.coma','333','1234567890','0000-00-00 00:00:00','2016-11-10 01:13:53'),(8,'Mabel Paez','mabel@fruandes.coma','333','1234567890',NULL,'2016-08-28 13:44:55'),(9,'Edisson Jaimes','edisson@fruandes.coma','333','1234567890',NULL,'2016-08-28 13:44:53'),(10,'Stefanny Alcantara ','stefanny@fruandes.coma','666','1234567890','2016-07-27 14:32:58','2016-08-11 13:02:19'),(11,'Giovanni Porras','giovanni@fruandes.coma','333','1234567890','2016-07-28 15:48:48','2016-08-28 13:44:48'),(12,'Janir Ledesma','janir@fruandes.coma','333','1234567890','2016-07-31 10:59:33','2016-08-28 13:44:46'),(13,'Fabio Barón','fabio@fruandes.coma','333','1234567890','2016-07-31 12:06:41','2016-08-28 13:44:41'),(14,'Juan David Mejía','juan@fruandes.coma','333','1234567890','2016-07-31 14:32:18','2016-08-28 13:44:39'),(15,'Germán Betancourt ','german@fruandes.coma','333','1234567890','2016-07-31 14:32:44','2016-08-28 13:44:36'),(16,'Jose Ignacio López','joseignacio@fruandes.coma','333','mariapaula2551','2016-08-10 10:02:34','2016-08-28 13:44:28'),(17,'Tatiana usme','tatiana.usme@fruandes.coma',NULL,'1234567890','2016-08-10 12:39:16','2016-08-10 12:39:16'),(18,'Tatiana Bustos','tatiana@fruandes.coma',NULL,'1234567890','2016-08-10 12:40:36','2016-08-10 12:40:36'),(19,'Juan Pablo Bayona','juanpablo@fruandes.coma',NULL,'1234567890','2016-08-10 12:41:40','2016-08-10 12:41:40'),(20,'Giset Llano','giset@fruandes.coma',NULL,'1234567890','2016-08-10 12:42:30','2016-08-10 12:42:30'),(22,'Neidhy Lopez','a',NULL,'1234567890','2016-08-10 12:46:47','2016-08-10 12:46:47'),(23,'Jairo Gallego','jairo@fruandes.coma',NULL,'1234567890','2016-08-10 12:48:58','2016-08-10 12:48:58'),(24,'yasmin Sanchez','yasmin@fruandes.coma',NULL,'1234567890','2016-08-10 12:51:24','2016-08-10 12:51:24'),(25,'Daniel Villarroel','daniel@guarinvillarroel.coma',NULL,'1234567890','2016-08-11 05:39:13','2016-08-11 05:39:13'),(26,'Jesus González','jesus.gonzalez@gecofi.coma',NULL,'1234567890','2016-08-11 05:40:48','2016-08-11 05:40:48'),(27,'Olga Macias','olga@fruandes.coma',NULL,'1234567890','2016-08-23 11:27:55','2016-08-23 11:27:55');
/*!40000 ALTER TABLE `usuarios_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-05 18:59:12
